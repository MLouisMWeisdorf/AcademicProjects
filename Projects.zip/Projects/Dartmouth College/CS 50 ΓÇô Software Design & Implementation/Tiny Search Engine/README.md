# CS50 TSE
## Louis Weisdorf (MLouisMWeisdorf)

The assignment and Specs are in a [public repo](https://github.com/CS50Spring2023/labs/tse).
Do not clone that repo; view it on GitHub.
Watch there for any commits that may represent updates to the assignment or specs.

Add here any assumptions you made while writing the crawler, any ways in which your implementation differs from the three Specs, or any ways in which you know your implementation fails to work.

