# Lib
The lib directory includes the given modules `mem`, which provides functions for handling memory, and `file`, which provides functions for reading files.