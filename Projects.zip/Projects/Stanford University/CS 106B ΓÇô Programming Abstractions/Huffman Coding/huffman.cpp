/*
 * @author - Louis Weisdorf
 * 11/28/2023 – CS 106B Fall 2023
 * Assignment 7.
 * The program huffman.cpp contains various functions allowing end-to-end
 * compression and decompression of a string input.
*/
#include "bits.h"
#include "treenode.h"
#include "huffman.h"
#include "map.h"
#include "vector.h"
#include "priorityqueue.h"
#include "strlib.h"
#include "SimpleTest.h"
#include "filelib.h"
using namespace std;

/*
 * Given a Queue<Bit> containing the compressed message bits and the original
 * encoding tree, decode the bits back to the original message text.
 *
 * You can assume that tree is a well-formed non-empty encoding tree and the
 * messageBits queue contains a valid sequence of encoded bits for that tree.
 *
 * Your implementation may change the messageBits queue however you like. There
 * are no requirements about its contents after this function returns.
 * The encoding tree should be unchanged.
 *
 * The function iterates through the messageBits queue, progressing through
 * the tree acordingly, and adding characters to the decoded string when
 * ending in a leaf node.
 */
string decodeText(EncodingTreeNode* tree, Queue<Bit>& messageBits) {
    string decoded;
    EncodingTreeNode* currentNode = tree;

    // Iterating through the queue of bits
    while (!messageBits.isEmpty()) {
        // If at leaf, add character to decoded string
        if (currentNode->isLeaf()) {
            decoded += currentNode->getChar();
            currentNode = tree;
        }

        Bit currentBit = messageBits.dequeue();

        // Go left if zero
        if (currentBit == 0) {
            currentNode = currentNode->zero;
        }

        // Go right if one
        if (currentBit == 1) {
            currentNode = currentNode->one;
        }
    }

    // Adding last leaf
    if (currentNode->isLeaf()) {
        decoded += currentNode->getChar();
    }

    return decoded;
}

/*
 * The function performs the recursive functionality needed to unflatten the tree.
 * The function reads bits from the treeShape queue, creating tree nodes accordingly.
 */
void unflattenTree(Queue<Bit>& treeShape, Queue<char>& treeLeaves, EncodingTreeNode*& tree) {
    if (treeShape.isEmpty()) {
        return;
    }

    Bit currentBit = treeShape.dequeue();

    // If the current node is to be a leaf
    if (currentBit == 0) {
        char currentChar = treeLeaves.dequeue();
        tree = new EncodingTreeNode(currentChar);
        return;
    }

    // If the current node is to have children
    if (currentBit == 1) {
        tree = new EncodingTreeNode(nullptr, nullptr);

        unflattenTree(treeShape, treeLeaves, tree->zero);
        unflattenTree(treeShape, treeLeaves, tree->one);
    }
}

/*
 * Reconstruct an encoding tree from flattened form Queue<Bit> and Queue<char>.
 *
 * You can assume that the queues are well-formed and the shape/leaves sequences
 * form a valid encoding tree.
 *
 * Your implementation may change the treeShape and treeLeaves queues however you like.
 * There are no requirements about their contents after this function returns.
 *
 * The function is a wrapper function, initializing variables needed for the recursive
 * function.
 */
EncodingTreeNode* unflattenTree(Queue<Bit>& treeShape, Queue<char>& treeLeaves) {
    EncodingTreeNode* tree = nullptr;
    unflattenTree(treeShape, treeLeaves, tree);

    return tree;
}

/*
 * Decompress the given EncodedData and return the original text.
 *
 * You can assume the data argument is well-formed and was created by a correct
 * implementation of compress.
 *
 * Your implementation may change the EncodedData however you like. There
 * are no requirements about its contents after this function returns.
 *
 * The function utilizes the helper functions to first unflatten the tree
 * and then decode the text.
 */
string decompress(EncodedData& data) {
    // Constructing the tree
    EncodingTreeNode* tree = unflattenTree(data.treeShape, data.treeLeaves);

    // Decoding the message
    string decoded = decodeText(tree, data.messageBits);

    // Deallocate the tree used in the process
    deallocateTree(tree);

    return decoded;
}

/*
 * Helper function for the buildHuffmanTree function, creating
 * a frequency map for the letters in the input string.
 * The function sends an error if the input string has less than
 * two distinct characters.
 */
void buildFrequencyMap(string text, Map<char, int>& frequencyMap) {
    // Iterating through text, incrementing count according
    for (char character: text) {
        frequencyMap[character]++;
    }

    // If fewer than two distinct characters, raising error
    if (frequencyMap.size() < 2) {
        error("The input text must contain at least two distinct characters.");
    }
}

/*
 * Constructs an optimal Huffman coding tree for the given text, using
 * the Huffman algorithm.
 *
 * Reports an error if the input text does not contain at least
 * two distinct characters.
 *
 * It can be helpful for you to establish/document the expected behavior of
 * choices re: tie-breaking, choice of which subtree on which side.
 * These choices do not affect correctness or optimality of resulting tree
 * but knowing which is used allows you to construct test cases that depend
 * on that behavior. Our provided test cases expect:
 *  -- our pqueue dequeues elems of equal priority in FIFO order
 *  -- when build new interior node, first elem dequeued placed as zero subtree
 *     and second elem dequeued placed as one subtree
 *
 * The function uses a helper function to create a frequency map for
 * the characters in the input string, then loads them into the priority queue.
 * To piece together the tree, two nodes are extracted from the prioroty queue
 * and inserted under a shared parent. When the entire tree has been assembled,
 * the root is returned.
 */
EncodingTreeNode* buildHuffmanTree(string text) {
    // Calling helper function to build frequency map
    Map<char, int> frequencyMap;
    buildFrequencyMap(text, frequencyMap);

    EncodingTreeNode* root = nullptr;

    // Inserting characters in priority queue
    PriorityQueue<EncodingTreeNode*> priority;

    for (char character : frequencyMap) {
        int frequency = frequencyMap.get(character);
        EncodingTreeNode* characterNode = new EncodingTreeNode(character);
        priority.enqueue(characterNode, frequency);
    }

    // Insert into tree until complete
    while (priority.size() > 1) {
        // Extract two smallest
        int zeroSum = priority.peekPriority();
        EncodingTreeNode* zero = priority.dequeue();
        int oneSum = priority.peekPriority();
        EncodingTreeNode* one = priority.dequeue();

        // Create parent for the characters extracted, inserting back into pq
        int sumFrequency = zeroSum + oneSum;
        EncodingTreeNode* parent = new EncodingTreeNode(zero, one);

        // Setting root of tree
        root = parent;

        priority.enqueue(parent, sumFrequency);
    }

    return root;
}

/*
 * The function performs the recursive functionality in creating a map of
 * characters and associates bit sequences. It recurses through the tree
 * updating the sequence of bits on its path, before finally inserting
 * the sequence into the map when reaching a leaf.
 */
void encodingMap(Map<char, Queue<Bit>>& map, EncodingTreeNode* tree, Queue<Bit> sequence) {
    // If at leaf, set sequence of bits
    if (tree->isLeaf()) {
        char currentChar = tree->getChar();
        map.put(currentChar, sequence);
        sequence.clear();
    }

    // If zero exists, go left
    if (tree->zero != nullptr) {
        Queue<Bit> updatedSequence = sequence;
        updatedSequence.enqueue(0);
        encodingMap(map, tree->zero, updatedSequence);
    }

    // If one exists, go right
    if (tree->one != nullptr) {
        Queue<Bit> updatedSequence = sequence;
        updatedSequence.enqueue(1);
        encodingMap(map, tree->one, updatedSequence);
    }
}

/*
 * The function is a wrapper function, initializing variables for the
 * function of the same name executing the recursive functionality.
 */
void encodingMap(Map<char, Queue<Bit>>& map, EncodingTreeNode* tree) {
    // Initializing sequence to pass to recursive function
    Queue<Bit> sequence;
    encodingMap(map, tree, sequence);
}

/*
 * Given a string and an encoding tree, encode the text using the tree
 * and return a Queue<Bit> of the encoded bit sequence.
 *
 * You can assume tree is a well-formed encoding tree and contains
 * an encoding for every character in the text.
 *
 * The function utilizes the helper function encodingMap to create
 * a map of characters and their associated bit sequence in the tree.
 * Then, it iterates over the characters in the text, retrieving the
 * associated bit queue, adding it to the encoded queue, which
 * is eventually returned.
 */
Queue<Bit> encodeText(EncodingTreeNode* tree, string text) {
    // Creating a map of character bit sequences with helper function
    Map<char, Queue<Bit>> encodedMap;
    encodingMap(encodedMap, tree);

    // Initializing encoded queue
    Queue<Bit> encodedQueue;

    // Iterating over characters in the text, retrieving sequences
    for (char character : text) {
        Queue<Bit> sequence = encodedMap.get(character);

        // Adding sequence to encoded queue
        while (!sequence.isEmpty()) {
            encodedQueue.enqueue(sequence.dequeue());
        }
    }

    return encodedQueue;
}

/*
 * Flatten the given tree into a Queue<Bit> and Queue<char> in the manner
 * specified in the assignment writeup.
 *
 * You can assume the input queues are empty on entry to this function.
 *
 * You can assume tree is a well-formed encoding tree.
 *
 * The function works recursively, pre-order traversing through the tree.
 * At interior nodes, a 1 is added to the treeShape queue and recursion
 * continues on children. At leaf nodes, a 0 is added to the treeShape
 * queue and the character to the treeLeaves queue (added in-order).
 */
void flattenTree(EncodingTreeNode* tree, Queue<Bit>& treeShape, Queue<char>& treeLeaves) {
    // If at a leaf, add 0 to shape queue and character to leaves queue
    if (tree->isLeaf()) {
        treeShape.enqueue(0);
        treeLeaves.enqueue(tree->getChar());
        return;
    }

    // If not at a leaf, add 1 to shape queue and recurse each way
    treeShape.enqueue(1);
    flattenTree(tree->zero, treeShape, treeLeaves);
    flattenTree(tree->one, treeShape, treeLeaves);
}

/*
 * Compress the message text using Huffman coding, producing as output
 * an EncodedData containing the encoded message bits and flattened
 * encoding tree.
 *
 * Reports an error if the message text does not contain at least
 * two distinct characters.
 *
 * The function handles the executive work in the compression
 * process, utilizing helper functions to first build the
 * Huffman tree, create the encode bit sequence, treeShape, and
 * treeLeaves, eventually gathering this data in an EncodedData
 * struct, which is returned.
 */
EncodedData compress(string messageText) {
    // Building the Huffman tree
    EncodingTreeNode* tree = buildHuffmanTree(messageText);

    // Creating encoded text
    Queue<Bit> messageBits = encodeText(tree, messageText);

    // Flattening tree, saving data in treeShape and treeLeaves queues
    Queue<Bit>  treeShape;
    Queue<char> treeLeaves;
    flattenTree(tree, treeShape, treeLeaves);
    deallocateTree(tree);

    // Gather data in EncodedData struct
    EncodedData result;
    result.messageBits = messageBits;
    result.treeShape = treeShape;
    result.treeLeaves = treeLeaves;

    return result;
}

/* * * * * * Testing Helper Functions Below This Point * * * * * */

EncodingTreeNode* createExampleTree() {
    /* Example encoding tree used in multiple test cases:
     *                *
     *              /   \
     *             T     *
     *                  / \
     *                 *   E
     *                / \
     *               R   S
     */
    // Creating leaf nodes for characters
    EncodingTreeNode* t = new EncodingTreeNode('T');
    EncodingTreeNode* r = new EncodingTreeNode('R');
    EncodingTreeNode* s = new EncodingTreeNode('S');
    EncodingTreeNode* e = new EncodingTreeNode('E');

    // Creating non-leaves, tying tree together
    EncodingTreeNode* bottom = new EncodingTreeNode(r, s);
    EncodingTreeNode* mid = new EncodingTreeNode(bottom, e);
    EncodingTreeNode* root = new EncodingTreeNode(t, mid);

    return root;
}

void deallocateTree(EncodingTreeNode* t) {
    // If empty tree
    if (t == nullptr) {
        return;
    }

    // If there is a zero, recurse zero (left)
    if (t->zero != nullptr) {
        deallocateTree(t->zero);
    }

    // If there is a one, recurse one (right)
    if (t->one != nullptr) {
        deallocateTree(t->one);
    }

    // Delete node itself after recursing children
    delete t;
}

bool areEqual(EncodingTreeNode* a, EncodingTreeNode* b) {
    // In case of empty trees (avoiding accessing non-existing memory
    if (a == nullptr && b == nullptr) {
        return true;
    }
    else if ((a == nullptr && b != nullptr) || (a != nullptr && b == nullptr)) {
        return false;
    }

    // If at leaf, check character
    if (a->isLeaf() && b->isLeaf()) {
        return a->getChar() == b->getChar();
    }

    // If both have zero, recurse left
    if (a->zero != nullptr && b->zero != nullptr) {
        EncodingTreeNode* aZero = a->zero;
        EncodingTreeNode* bZero = b->zero;
        return areEqual(aZero, bZero);
    }

    // If both have one, recurse right
    else if (a->one != nullptr && b->one != nullptr) {
        EncodingTreeNode* aOne = a->one;
        EncodingTreeNode* bOne = b->one;
        return areEqual(aOne, bOne);
    }

    // If discrepancy in number or direction of children
    else {
        return false;
    }
}

/* * * * * * Test Cases Below This Point * * * * * */

STUDENT_TEST("Testing createExampleTree function (via debugger) and deallocateTree") {
    EncodingTreeNode* example = createExampleTree();
    EXPECT(!(example == nullptr));

    deallocateTree(example);
}

STUDENT_TEST("Testing deallocateTree on empty tree") {
    EncodingTreeNode* empty = nullptr;
    deallocateTree(empty);
}

STUDENT_TEST("Testing areEqual on empty trees") {
    EncodingTreeNode* a = nullptr;
    EncodingTreeNode* b = nullptr;

    EXPECT(areEqual(a, b));
}

STUDENT_TEST("Testing areEqual on simple tree/empty tree") {
    EncodingTreeNode* zero = new EncodingTreeNode('A');
    EncodingTreeNode* one = new EncodingTreeNode('B');
    EncodingTreeNode* root = new EncodingTreeNode(zero, one);
    EncodingTreeNode* empty = nullptr;

    EXPECT(!areEqual(root, empty));
    deallocateTree(root);
}

STUDENT_TEST("Testing areEqual on equal simple trees") {
    EncodingTreeNode* zeroA = new EncodingTreeNode('A');
    EncodingTreeNode* oneA = new EncodingTreeNode('B');
    EncodingTreeNode* first = new EncodingTreeNode(zeroA, oneA);

    EncodingTreeNode* zeroB = new EncodingTreeNode('A');
    EncodingTreeNode* oneB = new EncodingTreeNode('B');
    EncodingTreeNode* second = new EncodingTreeNode(zeroB, oneB);

    EXPECT(areEqual(first, second));

    deallocateTree(first);
    deallocateTree(second);
}

STUDENT_TEST("Testing areEqual on non-equal simple trees") {
    EncodingTreeNode* zeroA = new EncodingTreeNode('A');
    EncodingTreeNode* oneA = new EncodingTreeNode('B');
    EncodingTreeNode* first = new EncodingTreeNode(zeroA, oneA);

    EncodingTreeNode* zeroB = new EncodingTreeNode('A');
    EncodingTreeNode* oneB = new EncodingTreeNode('B');
    EncodingTreeNode* second = new EncodingTreeNode(oneB, zeroB);

    EXPECT(!areEqual(first, second));

    deallocateTree(first);
    deallocateTree(second);
}

STUDENT_TEST("Testing areEqual on example and simple tree") {
    EncodingTreeNode* zero = new EncodingTreeNode('A');
    EncodingTreeNode* one = new EncodingTreeNode('B');
    EncodingTreeNode* simple = new EncodingTreeNode(zero, one);
    EncodingTreeNode* example = createExampleTree();

    EXPECT(!areEqual(simple, example));

    deallocateTree(simple);
    deallocateTree(example);
}

STUDENT_TEST("Testing areEqual on examples") {
    EncodingTreeNode* first = createExampleTree();
    EncodingTreeNode* second = createExampleTree();

    EXPECT(areEqual(first, second));

    deallocateTree(first);
    deallocateTree(second);
}

STUDENT_TEST("Testing areEqual on example and subtree") {
    EncodingTreeNode* example = createExampleTree();
    EncodingTreeNode* zero = new EncodingTreeNode('R');
    EncodingTreeNode* one = new EncodingTreeNode('S');
    EncodingTreeNode* sub = new EncodingTreeNode(zero, one);

    EXPECT(!areEqual(example, sub));

    deallocateTree(example);
    deallocateTree(sub);
}

STUDENT_TEST("decodeText, simple tree with unmixed and mixed bit inputs") {
    EncodingTreeNode* zero = new EncodingTreeNode('A');
    EncodingTreeNode* one = new EncodingTreeNode('B');
    EncodingTreeNode* root = new EncodingTreeNode(zero, one);
    EXPECT(root != nullptr);

    Queue<Bit> messageBits = {0,1}; // E
    EXPECT_EQUAL(decodeText(root, messageBits), "AB");

    messageBits = {1,1,1,1};
    EXPECT_EQUAL(decodeText(root, messageBits), "BBBB");

    messageBits = {0,0,0,0};
    EXPECT_EQUAL(decodeText(root, messageBits), "AAAA");

    messageBits = {0,1,0,1};
    EXPECT_EQUAL(decodeText(root, messageBits), "ABAB");

    deallocateTree(root);
}

STUDENT_TEST("unflattenTree debugger test") {
    Queue<Bit>  treeShape  = {1,0,1,0,0};
    Queue<char> treeLeaves = {'E','W','K'};
    EncodingTreeNode* tree = unflattenTree(treeShape, treeLeaves);

    deallocateTree(tree);
}

STUDENT_TEST("unflattenTree compare to example in writeup") {
    // Creating tree from writeup
    EncodingTreeNode* e = new EncodingTreeNode('E');
    EncodingTreeNode* w = new EncodingTreeNode('W');
    EncodingTreeNode* k = new EncodingTreeNode('K');
    EncodingTreeNode* mid = new EncodingTreeNode(w, k);
    EncodingTreeNode* root = new EncodingTreeNode(e, mid);

    // Constructing tree with unflatten function
    Queue<Bit>  treeShape  = {1,0,1,0,0};
    Queue<char> treeLeaves = {'E','W','K'};
    EncodingTreeNode* tree = unflattenTree(treeShape, treeLeaves);

    EXPECT(areEqual(tree, root));

    deallocateTree(tree);
    deallocateTree(root);
}

STUDENT_TEST("decompress, examples from warmup") {
    EncodedData data = {
        {1,0,1,0,0},            // treeShape
        {'E','W','K'},          // treeLeaves
        {1,0,0,0,1,1}           // messageBits
    };

    EXPECT_EQUAL(decompress(data), "WEEK");

    data = {
        {1,0,1,1,0,0,0},            // treeShape
        {'A','D','B','N'},          // treeLeaves
        {1,0,1,0,1,1,1,0,0}         // messageBits
    };

    EXPECT_EQUAL(decompress(data), "BAND");

    data = {
        {1,1,0,1,0,0,0},            // treeShape
        {'N','M','S','O'},          // treeLeaves
        {0,1,0,1,1,0,0,0,1,1}       // messageBits
    };

    EXPECT_EQUAL(decompress(data), "MOONS");
}

STUDENT_TEST("encodingMap helper function, comparing to warmup") {
    Queue<Bit>  treeShape  = {1,1,0,1,0,0,0};
    Queue<char> treeLeaves = {'N','M','S','O'};
    EncodingTreeNode* tree = unflattenTree(treeShape, treeLeaves);

    Map<char, Queue<Bit>> encodedMap;
    encodingMap(encodedMap, tree);

    Map<char, Queue<Bit>> expected = {
        {'M', {0, 1, 0}},
        {'N', {0, 0}},
        {'O', {1}},
        {'S', {0, 1, 1}}
    };

    EXPECT(encodedMap.equals(expected));

    deallocateTree(tree);
}

STUDENT_TEST("encodeText, small fixed inputs, warmup encoding tree") {
    Queue<Bit>  treeShape  = {1,1,0,1,0,0,0};
    Queue<char> treeLeaves = {'N','M','S','O'};
    EncodingTreeNode* tree = unflattenTree(treeShape, treeLeaves);

    Queue<Bit> messageBits = {1}; // O
    EXPECT_EQUAL(encodeText(tree, "O"), messageBits);

    messageBits = {0,1,1,1,0,0};    // SON
    EXPECT_EQUAL(encodeText(tree, "SON"), messageBits);

    messageBits = {0,1,0,1,1,0,0,0,1,1}; // MOONS
    EXPECT_EQUAL(encodeText(tree, "MOONS"), messageBits);

    deallocateTree(tree);
}

STUDENT_TEST("encodeText paired with decodeText") {
    Queue<Bit>  treeShape  = {1,1,0,1,0,0,0};
    Queue<char> treeLeaves = {'N','M','S','O'};
    EncodingTreeNode* tree = unflattenTree(treeShape, treeLeaves);

    string input = "O";
    Queue<Bit> encodeResult = encodeText(tree, input);
    string decodeResult = decodeText(tree, encodeResult);
    EXPECT_EQUAL(decodeResult, input);

    input = "SON";
    encodeResult = encodeText(tree, input);
    decodeResult = decodeText(tree, encodeResult);
    EXPECT_EQUAL(decodeResult, input);

    input = "MOONS";
    encodeResult = encodeText(tree, input);
    decodeResult = decodeText(tree, encodeResult);
    EXPECT_EQUAL(decodeResult, input);

    deallocateTree(tree);
}

STUDENT_TEST("flattenTree function with unflattenTree on writeup example") {
    // Creating tree from writeup
    EncodingTreeNode* e = new EncodingTreeNode('E');
    EncodingTreeNode* w = new EncodingTreeNode('W');
    EncodingTreeNode* k = new EncodingTreeNode('K');
    EncodingTreeNode* mid = new EncodingTreeNode(w, k);
    EncodingTreeNode* root = new EncodingTreeNode(e, mid);

    // Flattening tree
    Queue<Bit>  treeShape;
    Queue<char> treeLeaves;
    flattenTree(root, treeShape, treeLeaves);

    // Reconstructing tree with unflatten function
    EncodingTreeNode* tree = unflattenTree(treeShape, treeLeaves);

    EXPECT(areEqual(tree, root));

    deallocateTree(tree);
    deallocateTree(root);
}

STUDENT_TEST("buildFrequencyMap helper function") {
    string input = "bookkeeper";

    Map<char, int> frequencyMap;
    buildFrequencyMap(input, frequencyMap);

    Map<char, int> expected = {
        {'b', 1},
        {'o', 2},
        {'k', 2},
        {'e', 3},
        {'p', 1},
        {'r', 1}
    };

    EXPECT(frequencyMap.equals(expected));
}

STUDENT_TEST("buildHuffmanTree on invalid input") {
    string input = "aa";
    EXPECT_ERROR(buildHuffmanTree(input));
}

STUDENT_TEST("buildHuffmanTree on example from warmup") {
    string input = "Bookkeeper";
    EncodingTreeNode* tree = buildHuffmanTree(input);

    // Building reference tree
    Queue<Bit> treeShape = {1,1,0,0,1,1,0,1,0,0,0};
    Queue<char> treeLeaves = {'o','k','B','r','p','e'};
    EncodingTreeNode* reference = unflattenTree(treeShape, treeLeaves);

    EXPECT(areEqual(tree, reference));

    deallocateTree(tree);
    deallocateTree(reference);
}

STUDENT_TEST("End-to-end compress to decompress, empty input") {
    string input = "";

    EXPECT_ERROR(compress(input));
}

STUDENT_TEST("End-to-end compress to decompress, all caps") {
    string input = "PERFORMING AN END TO END TEST OF THE COMPRESSION/DECOMPRESSION FUNCTIONS";

    EncodedData data = compress(input);
    string output = decompress(data);

    EXPECT_EQUAL(input, output);
}

STUDENT_TEST("End-to-end compress to decompress, mixed caps") {
    string input = "Performing an end to end test of the compression/decompression functions";

    EncodedData data = compress(input);
    string output = decompress(data);

    EXPECT_EQUAL(input, output);
}

STUDENT_TEST("End-to-end compress to decompress, seuss.txt excerpt") {
    string input = "I am Sam"
                   "Sam I am"
                   "that Sam I am"
                   "that Sam I am";

    EncodedData data = compress(input);
    string output = decompress(data);

    EXPECT_EQUAL(input, output);
}

STUDENT_TEST("End-to-end compress to decompress, dream.txt file") {
    string pathname = "res/dream.txt";
    ifstream in;

    if (!openFile(in, pathname))
        error("Cannot open file named " + pathname);

    Vector<string> lines = readLines(in);

    for (string input: lines) {
        if (input != "") {
            EncodedData data = compress(input);
            string output = decompress(data);

            EXPECT_EQUAL(input, output);
        }
    }
}

/* * * * * Provided Tests Below This Point * * * * */

PROVIDED_TEST("decodeText, small fixed inputs, example encoding tree") {
    EncodingTreeNode* tree = createExampleTree(); // see diagram above
    EXPECT(tree != nullptr);

    Queue<Bit> messageBits = {1,1}; // E
    EXPECT_EQUAL(decodeText(tree, messageBits), "E");

    messageBits = {1,0,1,1,1,0}; // SET
    EXPECT_EQUAL(decodeText(tree, messageBits), "SET");

    messageBits = {1,0,1,0,1,0,0,1,1,1,1,0,1,0,1}; // STREETS
    EXPECT_EQUAL(decodeText(tree, messageBits), "STREETS");

    deallocateTree(tree);
}

PROVIDED_TEST("unflattenTree, example encoding tree") {
    EncodingTreeNode* reference = createExampleTree(); // see diagram above
    Queue<Bit>  treeShape  = {1,0,1,1,0,0,0};
    Queue<char> treeLeaves = {'T','R','S','E'};
    EncodingTreeNode* tree = unflattenTree(treeShape, treeLeaves);

    EXPECT(areEqual(tree, reference));

    deallocateTree(tree);
    deallocateTree(reference);
}

PROVIDED_TEST("decompress, small fixed input, example encoding tree") {
    EncodedData data = {
        {1,0,1,1,0,0,0},            // treeShape
        {'T','R','S','E'},          // treeLeaves
        {0,1,0,0,1,1,1,0,1,1,0,1}   // messageBits
    };

    EXPECT_EQUAL(decompress(data), "TRESS");
}

PROVIDED_TEST("buildHuffmanTree, small fixed input, example encoding tree") {
    EncodingTreeNode* reference = createExampleTree(); // see diagram above
    EncodingTreeNode* tree = buildHuffmanTree("STREETTEST");
    EXPECT(areEqual(tree, reference));

    deallocateTree(reference);
    deallocateTree(tree);
}

PROVIDED_TEST("encodeText, small fixed inputs, example encoding tree") {
    EncodingTreeNode* reference = createExampleTree(); // see diagram above

    Queue<Bit> messageBits = {1,1}; // E
    EXPECT_EQUAL(encodeText(reference, "E"), messageBits);

    messageBits = {1,0,1,1,1,0};    // SET
    EXPECT_EQUAL(encodeText(reference, "SET"), messageBits);

    messageBits = {1,0,1,0,1,0,0,1,1,1,1,0,1,0,1}; // STREETS
    EXPECT_EQUAL(encodeText(reference, "STREETS"), messageBits);

    deallocateTree(reference);
}

PROVIDED_TEST("flattenTree, example encoding tree") {
    EncodingTreeNode* reference = createExampleTree(); // see diagram above
    Queue<Bit>  expectedShape  = {1,0,1,1,0,0,0};
    Queue<char> expectedLeaves = {'T','R','S','E'};

    Queue<Bit>  treeShape;
    Queue<char> treeLeaves;
    flattenTree(reference, treeShape, treeLeaves);

    EXPECT_EQUAL(treeShape,  expectedShape);
    EXPECT_EQUAL(treeLeaves, expectedLeaves);

    deallocateTree(reference);
}

PROVIDED_TEST("compress, small fixed input, example encoding tree") {
    EncodedData data = compress("STREETTEST");
    Queue<Bit>  treeShape   = {1,0,1,1,0,0,0};
    Queue<char> treeChars   = {'T','R','S','E'};
    Queue<Bit>  messageBits = {1,0,1,0,1,0,0,1,1,1,1,0,0,1,1,1,0,1,0};

    EXPECT_EQUAL(data.treeShape, treeShape);
    EXPECT_EQUAL(data.treeLeaves, treeChars);
    EXPECT_EQUAL(data.messageBits, messageBits);
}

PROVIDED_TEST("Test end-to-end compress -> decompress, small fixed inputs") {
    Vector<string> inputs = {
        "HAPPY HIP HOP",
        "Nana Nana Nana Nana Nana Nana Nana Nana Batman",
        "Research is formalized curiosity. It is poking and prying with a purpose. – Zora Neale Hurston",
    };

    for (string input: inputs) {
        EncodedData data = compress(input);
        string output = decompress(data);

        EXPECT_EQUAL(input, output);
    }
}
